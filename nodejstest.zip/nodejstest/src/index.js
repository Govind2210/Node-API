const express= require("express");
//import faker
const faker=require('faker');
//import body-parser
var  bodyParser = require('body-parser')
const app=express();
const port =3000;

//setting ejs
app.set('view engine', 'ejs');

app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: false }))

const users=[];
for(let i=1;i<5;i++){
    users.push({
        id:i,
        name:faker.name.findName(),
        email:faker.internet.email(),
        age:parseInt(Math.random((faker.datatype.number()))*100),
        city:faker.address.city(),
        profession:faker.name.jobTitle()
    })
}
console.log(users);

app.get("/",(req,res)=>{
    res.render("../views/home.ejs",{users})
})

app.get("/form",(req,res)=>{
    res.render("../views/form.ejs")
})

//method post
app.post("/user/add",(req,res)=>{
    console.log(req.body);
    users.push({
        name:req.body.name,
        email:req.body.email,
        age:req.body.age,
        city:req.body.city,
        profession:req.body.profession})
        res.redirect("/")
})
app.listen(port,()=>{
    console.log("server is connected at port "+ port)
})

